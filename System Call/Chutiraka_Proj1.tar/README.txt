# Name: (Ya) Naweeya Chutiraka
# UFID: 46633911
# Gator ID: nc10nchu

In my makefile, I make it run both 
- existng makefile for system call,
- existing makefile for library call
Other than that, it 
- generates an executable of my test program called procedure.
- patch every file I made modification in

My make file will, in total, take 20-30 minutes to run. 

I did not include 
- reboot,
- ./procedure (my executable is named procedure) 
in my makefile.
So please do that separately after you finish running my makefile. 
(I am not sure if you do not reboot, you will be able to see all changes or not)
Please separately patch all changes to your files where they are located.


There are some files in my tar file that are there only for testing purposes, such as printmsg or printppid. If you do not need to to grade them, feel free to ignore them