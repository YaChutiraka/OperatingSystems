#include <stdio.h>
#include "Buffer.h"

struct Buffer buff[1024];
int on_off;
int curr_index;

int do_get_plog_size(){

	int size = 1024;	
	return size; // always this size
	

}


